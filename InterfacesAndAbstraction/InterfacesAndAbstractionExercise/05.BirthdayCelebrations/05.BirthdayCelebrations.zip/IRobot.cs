﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05.BirthdayCelebrations
{
    public interface IRobot
    {
        public string Model { get; set; }
        public string Id { get; set; }
    }
}

