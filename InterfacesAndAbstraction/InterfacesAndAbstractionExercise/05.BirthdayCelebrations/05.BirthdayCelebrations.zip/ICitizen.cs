﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05.BirthdayCelebrations
{
    public interface ICitizen
    {
        public int Age { get; set; }
        public string Id { get; set; }

    }
}
