﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Telephony
{
    public interface ISmart
    {
        public string Browse(string url);
    }
}
